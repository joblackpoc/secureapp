Management Commands
===================

Status
------
.. autoclass:: two_factor.management.commands.two_factor_status.Command

Disable
-------
.. autoclass:: two_factor.management.commands.two_factor_disable.Command
