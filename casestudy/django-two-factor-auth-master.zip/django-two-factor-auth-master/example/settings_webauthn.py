from .settings import *  # noqa: F403

INSTALLED_APPS.extend(['two_factor.plugins.webauthn'])  # noqa: F405
